<?php

// Constantes liées à la base de données
define('BDD_HOTE', 'localhost');
define('BDD_NOM', 'budget_manager');
define('BDD_UTILISATEUR', 'budget_user');
define('BDD_MOT_DE_PASSE', 'budget_super');
define('BDD_CHARSET', 'utf8mb4');