# MLD

- Utilisateur(id_user, email, mot-passe, remediation, #id_groupe, #id_role);

- Groupe(id_groupe, impots, loyer, credit, mois_budget);

- Role(id_role, nom_role);

- Salaire(id_salaire, somme, mois_salaire, #id_user);

- Depense(id_depense, nom_depense, montant, date, #id_categorie);

- Catégorie(id_categorie, nom_categorie);